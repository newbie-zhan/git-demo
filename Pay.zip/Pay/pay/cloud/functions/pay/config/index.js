const fs = require('fs');
const path = require('path');

module.exports = {
  mpAppId: '', // 小程序appid
  envName: '', // TCB环境ID
  MCHID: '',//商户id
  KEY: '',
  TIMEOUT: 10000 // 毫秒
};