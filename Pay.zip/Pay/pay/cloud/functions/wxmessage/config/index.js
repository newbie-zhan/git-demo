module.exports = {
  secret: '', // 小程序 secret
  templateId: '' 
  // 模板 id
};