module.exports = {
    secret: 'xxxx', // 小程序 secret id
    templateId: 'xxxxx' // 模板 id
};