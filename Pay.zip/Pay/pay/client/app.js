// app.js
App({
  onLaunch () {
    wx.cloud.init({
      traceUser: true
    });
  }
})
